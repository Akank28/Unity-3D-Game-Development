﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LaunchClick : MonoBehaviour {
    public float launchForce = 1000;
    public GameObject player;
    public Rigidbody rigidbody;

	// Use this for initialization
	void Start () {
      rigidbody = GetComponent<Rigidbody>();
      // rigidbody.AddForce(launchForce * transform.forward);
    player = GameObject.FindGameObjectWithTag("Player");
}
	
	// Update is called once per frame
	void Update () {
		
	}
    private void OnMouseDown()
    {
        player.GetComponent<Rigidbody>().AddForce(launchForce*transform.forward);
        
       
    }
}
